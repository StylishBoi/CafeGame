## Radial fill shader

This shader helps to create radial fill with sprite

![](https://github.com/Nrjwolf/unity-shader-sprite-radial-fill/blob/master/gif.gif "Usage")
